local index = 1
while(actions[index] ~= nil) do
    if(actions[index].id == "DRAW_3_RANDOM") then
        table.remove(actions, index)
        table.insert(actions, index, 
        {
		id          = "DRAW_3_RANDOM",
		name 		= "$action_draw_3_random",
		description = "$actiondesc_draw_3_random",
		sprite 		= "data/ui_gfx/gun_actions/draw_3_random.png",
		sprite_unidentified = "data/ui_gfx/gun_actions/spread_reduce_unidentified.png",
		spawn_requires_flag = "card_unlocked_pyramid",
		type 		= ACTION_TYPE_OTHER,
		recursive	= true,
		spawn_level                       = "2,3,5,6,10", -- MANA_REDUCE
		spawn_probability                 = "0.1,0.2,0.1,0.1,1", -- MANA_REDUCE
		price = 200,
		mana = 40,
		action 		= function( recursion_level, iteration )
			SetRandomSeed( GameGetFrameNum() + #deck, GameGetFrameNum() - 325 + #discarded )
			local datasize = #deck + #discarded
            
            local randomSpells = {}
            local rec = {}
			
			for i=1,3 do
				local rnd = Random( 1, datasize )
				
				local data = {}
				
				if ( rnd <= #deck ) then
					data = deck[rnd]
				else
					data = discarded[rnd - #deck]
				end
				
				local checks = 0
				rec[i] = check_recursion( data, recursion_level )
				
				while ( data ~= nil ) and ( ( rec[i] == -1 ) or ( ( data.uses_remaining ~= nil ) and ( data.uses_remaining == 0 ) ) ) and ( checks < datasize ) do
					rnd = ( rnd % datasize ) + 1
					checks = checks + 1
					
					if ( rnd <= #deck ) then
						data = deck[rnd]
					else
						data = discarded[rnd - #deck]
					end
					
					rec[i] = check_recursion( data, recursion_level )
				end
				
				if ( data ~= nil ) and ( rec[i] > -1 ) and ( ( data.uses_remaining == nil ) or ( data.uses_remaining ~= 0 ) ) then
                        
                        randomSpells[i] = data
					
					if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
						data.uses_remaining = data.uses_remaining - 1
						
						local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
						if not reduce_uses then
							data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction
						end
					end
				end
			end
        
            for i=1,3 do
                if ( randomSpells[i] ~= nil ) and ( rec[i] > -1 ) then
                    randomSpells[i].action( rec[i] )
                end
            end
		end,
	})
    return
    end
    index = index + 1;
end