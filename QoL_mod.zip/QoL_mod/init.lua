
if (ModIsEnabled("nightmare")) then
    ModLuaFileAppend( "mods/nightmare/files/biome_map.lua", "mods/QoL_mod/files/biome_map_append.lua")
end

--Chainsaw fix
local fileContents = ModTextFileGetContent("data/entities/projectiles/deck/chainsaw.xml")
local replace_start = "<AudioLoopComponent"
local replace_end = "</AudioLoopComponent>"
fileContents = string.gsub(fileContents, replace_start, "<!--")
fileContents = string.gsub(fileContents, replace_end, "-->")
ModTextFileSetContent("data/entities/projectiles/deck/chainsaw.xml", fileContents)

--Copy three fix

ModLuaFileAppend( "data/scripts/gun/gun_actions.lua", "mods/QoL_mod/files/gun_actions_append.lua")

--Perk list enums

local fileContents = ModTextFileGetContent("data/scripts/perks/perk_list.lua")
local missingEnums = ModTextFileGetContent("mods/QoL_mod/files/perk_list_prepend.lua")
local combine = missingEnums .. fileContents
ModTextFileSetContent("data/scripts/perks/perk_list.lua", combine)

--Runestone fix

local fileContents = ModTextFileGetContent("data/scripts/item_spawnlists.lua")
local pattern = "SetRandomSeed"
fileContents = string.gsub(fileContents, pattern, "--", 1)
ModTextFileSetContent("data/scripts/item_spawnlists.lua", fileContents)