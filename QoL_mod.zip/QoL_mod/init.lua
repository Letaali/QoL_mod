
if (ModIsEnabled("nightmare")) then
    ModLuaFileAppend( "mods/nightmare/files/biome_map.lua", "mods/QoL_mod/files/biome_map_append.lua")
end

--function OnModInit()
	--ModTextFileSetContent("data/entities/projectiles/deck/chainsaw.xml", "mods/QoL_mod/data/entities/projectiles/deck/chainsaw.xml")
--end

